<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<h1> <b>B & S</b> Buen Servicio</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <?php if(auth()->user()->is_admin): ?>
    <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                    <div class="row text-center">
                        <div class="col-lg-4 col-4">
                            <h3> </h3>
                            <p> Horas Realizadas </p>
                        </div>
                        <div class="col-lg-8 col-8 mt-2">
                            <p> <b> <?php echo e($total_horas); ?> </b> <br>
                        </div>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="<?php echo e(route('jornada_laborals.suma')); ?>" class="small-box-footer">Más info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="row text-center">
                        <div class="col-lg-4 col-4">
                            <h3> </h3>
                            <p> Jornadas Realizadas </p>
                        </div>
                        <div class="col-lg-8 col-8 mt-2">
                            <p> <b> <?php echo e($total_jornadas); ?> </b> <br>
                        </div>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="<?php echo e(route('jornada_laborals.horastrabajadas')); ?>" class="small-box-footer">Más info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <div class="small-box" style="background-color: #7a57af; color:white">
                    <div class="row text-center">
                        <div class="col-lg-4 col-4">
                            <h3> </h3>
                            <p> Emleados Activos </p>
                        </div>
                        <div class="col-lg-8 col-8 mt-2">

                            <p> <b><?php echo e($total_usuarios); ?> </b> <br>
                        </div>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="<?php echo e(route('usuarios.index')); ?>" class="small-box-footer">Más info <i class="fas fa-arrow-circle-right"></i></a>

                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box" style="background-color:orange; color:white">
                    <div class="row text-center">
                        <div class="col-lg-4 col-4">
                            <h3></h3>
                            <p> Clientes Activos </p>
                        </div>
                        <div class="col-lg-8 col-8 mt-2">
                        <p> <b> ? </b> <br>
                        </div>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="" class="small-box-footer">Más info <i class="fas fa-arrow-circle-right"></i></a>

                </div>
            </div>
            <!-- ./col -->
        </div>
        <!-- /.row -->

    </div><!-- /.container-fluid -->
    <?php endif; ?>

    <section class="col-lg-4 connectedSortable">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('jornada-livewire', []);

$__html = app('livewire')->mount($__name, $__params, 'szcEFTw', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </section>

    <section class="col-lg-8 connectedSortable">
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/osneida/Proyectos/Berginie/bs_buenservicio/resources/views/admin/index.blade.php ENDPATH**/ ?>